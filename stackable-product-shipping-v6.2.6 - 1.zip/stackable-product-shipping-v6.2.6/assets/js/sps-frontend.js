/**
 * SPS Frontend JavaScript
 * Stackable Product Shipping v7
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        console.log('SPS Frontend carregado');
    });

})(jQuery);